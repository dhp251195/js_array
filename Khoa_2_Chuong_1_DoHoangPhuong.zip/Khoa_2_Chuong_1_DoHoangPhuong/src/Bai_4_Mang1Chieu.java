//Liệt kê phần tử toàn số lẻ

import java.util.Scanner;

public class Bai_4_Mang1Chieu {

	static final int MIN = -1000;
	static final int MAX = 1000;

	public Bai_4_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = taoMang(n);
		xuatMang(a);
		System.out.println("Phần tử thỏa mãn yêu cầu là:");
		lietKe(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] taoMang(int n) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = MIN + (int) (Math.random() * ((MAX - MIN) + 1));
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static boolean kTraDieuKien(int x) {
		if (x % 2 != 0) {
			do {
				x /= 10;
				if (x % 2 == 0) {
					return false;
				}
			} while (x > 10);
		} else {
			return false;
		}
		return true;
	}

	public static void lietKe(int a[]) {
		for (int i = 0; i < a.length; i++) {
			if (kTraDieuKien(a[i])) {
				System.out.print("a[" + i + "]:" + a[i] + "\t");
			}
		}
	}
}
