//dịch phải xoay vòng k lần
import java.util.Scanner;

public class Bai_15_Mang1Chieu {

	static final int MIN = -100;
	static final int MAX = 100;

	public Bai_15_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = taoMang(n);
		xuatMang(a);
		a = xoayPhai(a, scan);
		xuatMang(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n <= 0);
		return n;
	}

	public static int[] taoMang(int n) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = MIN + (int) (Math.random() * ((MAX - MIN) + 1));
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int item : a) {
			System.out.print(item + "\t");
		}
		System.out.println("\n");
	}

	public static int[] xoayPhai(int a[], Scanner scan) {
		int k;
		int temp;
		do {
			System.out.println("Vui lòng nhập số k > 0");
			k = Integer.parseInt(scan.nextLine());
		} while (k < 1);
		k %= a.length;
		for (int i = 0; i < k; i++) {
			temp = a[a.length - 1];
			for (int j = a.length - 1; j > 0; j--) {
				a[j] = a[j - 1];
			}
			a[0] = temp;
		}
		return a;
	}
}
