//Liệt kê phần tử có số đầu tiên chẵn

import java.util.Scanner;

public class Bai_5_Mang1Chieu {

	public Bai_5_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		System.out.println("Phần tử thỏa mãn yêu cầu là:");
		lietKe(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static boolean kTraDieuKien(int x) {
		while (x > 10) {
			x /= 10;
		}
		if(x%2!=0) {
			return false;
		}
		return true;
	}

	public static void lietKe(int a[]) {
		for (int i = 0; i < a.length; i++) {
			if (kTraDieuKien(a[i])) {
				System.out.print("a[" + i + "]:" + a[i] + "\t");
			}
		}
	}
}