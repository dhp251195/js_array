import java.util.Scanner;

public class Bai_16_Mang1Chieu {

	public Bai_16_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		pTuXuatHienNhieuNhat(a);
		pTuXuatHienItNhat(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static void pTuXuatHienNhieuNhat(int a[]) {
		int most = 0;
		int mostHead = 0;
		int head = 0;
		do {
			int count = 0;
			for (int i = head; i < a.length; i++) {
				if (a[head] == a[i]) {
					count++;
				}
			}
			if (count > most) {
				most = count;
				mostHead = head;
			}
			head++;
		} while (head < a.length);
		System.out.println("Phần tử xuất hiện nhiều nhất đầu tiên là: " + a[mostHead] + '[' + most + " lần]");
	}

	public static void pTuXuatHienItNhat(int a[]) {
		int least = 1000;
		int leastHead = 0;
		int head = 0;
		do {
			int count = 0;
			for (int i = 0; i < a.length; i++) {
				if (a[head] == a[i]) {
					count++;
				}
			}
			if (count < least) {
				least = count;
				leastHead = head;
			}
			head++;
		} while (head < a.length);
		System.out.println("Phần tử xuất hiện ít nhất đầu tiên là: " + a[leastHead] + '[' + least + " lần]");
	}

}
