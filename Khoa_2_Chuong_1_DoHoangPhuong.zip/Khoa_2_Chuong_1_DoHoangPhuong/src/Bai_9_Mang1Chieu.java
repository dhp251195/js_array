//TB Cộng các số nguyên tố trong mảng

import java.util.Scanner;

public class Bai_9_Mang1Chieu {

	static final int MIN = -1000;
	static final int MAX = 1000;

	public Bai_9_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[]= taoMang(n);
		xuatMang(a);
		ketQua(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] taoMang(int n) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = MIN + (int) (Math.random() * ((MAX - MIN) + 1));
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static int kTraSoNguyenTo(int x) {
		if (x < 2) {
			return 0;
		} else {
			for (int i = 2; i <= x / 2; i++) {
				if (x % i == 0)
					return 0;
			}
			return 1;
		}
	}

	public static void ketQua(int a[]) {
		int count = 0;
		int sum = 0;
		float tbCong = 0;
		System.out.println("Các số nguyên tố trong mảng là: ");
		for (int i = 0; i < a.length; i++) {
			if (kTraSoNguyenTo(a[i]) == 1) {
				System.out.print("a[" + i + "]:" + a[i] + "\t");
				sum += a[i];
				count++;
			}
		}
		if (count == 0) {
			System.out.println("Mảng không có số nguyên tố");
		} else {
			tbCong = (1.0f*sum) / count;
			System.out.println("\n");
			System.out.println("Trung bình cộng các số nguyên tố là: " + tbCong);
		}
	}
}
