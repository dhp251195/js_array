//Tính tổng các số có hàng chục là 5

import java.util.Scanner;

public class Bai_7_Mang1Chieu {

	public Bai_7_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		ketQua(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static boolean xetDieuKien(int x) {
		int numb = x / 10;
		if (x > 10 && numb % 10 == 5) {
			return true;
		}
		return false;
	}

	public static void ketQua(int a[]) {
		int sum = 0;
		for (int item : a) {
			if (xetDieuKien(Math.abs(item))) {
				System.out.print(item + "\t");
				sum += item;
			}
		}
		System.out.println("\n");
		System.out.println("Tổng các số có hàng chục là 5 có trong mảng là: " + sum);
	}
}
