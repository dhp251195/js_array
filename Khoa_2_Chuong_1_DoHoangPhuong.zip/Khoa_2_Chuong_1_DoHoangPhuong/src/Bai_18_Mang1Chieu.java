import java.util.Scanner;

public class Bai_18_Mang1Chieu {

	public Bai_18_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		System.out.println("Những phần tử xuất hiện nhiều nhất là:");
		int most = soLanXuatHienNhieuNhat(a);
		inKQua(a, most);
	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static int soLanXuatHienNhieuNhat(int a[]) {
		int most = 0;
		int mostHead = 0;
		int head = 0;
		int count;
		do {
			count = 0;
			for (int i = head; i < a.length; i++) {
				if (a[head] == a[i]) {
					count++;
				}
			}
			if (count > most) {
				most = count;
				mostHead = head;
			}
			head++;
		} while (head < a.length);
		
		return most;
	}
	
	public static void inKQua (int a[], int most) {
		for(int i = 0; i < a.length; i++) {
			int count = 0;
			for(int j = i; j<a.length; j++) {

				if(a[i]==a[j]) {
					count++;
				}
				if(count == most) {
					System.out.print(a[i] + "["+most+" lần]"+"\t");
					break;
				}
			}
		}
	}

}
