
//xóa số chính phương trong mảng
import java.util.Scanner;

public class Bai_14_Mang1Chieu {

	public Bai_14_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		int count = demSoChinhPhuong(a);
		if (count == 0) {
			System.out.println("Mảng không có số chính phương");
		} else if (n == count) {
			System.out.println("Mảng không còn phần tử nào");
		} else {
			System.out.println("Mảng sau khi xóa số chính phương là");
			a = xoaSoChinhPhuong(a, count);
			xuatMang(a);
		}
	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static boolean kTraSoChinhPhuong(int x) {
		for (int i = 0; i * i <= x; i++) {
			if (i * i == x) {
				return true;
			}
		}
		return false;
	}

	public static int demSoChinhPhuong(int a[]) {
		int count = 0;
		for (int item : a) {
			if (kTraSoChinhPhuong(item)) {
				count++;
			}
		}
		return count;
	}

	public static int[] xoaSoChinhPhuong(int a[], int count) {
		int b[] = new int[a.length - count];
		int j = 0;
		for (int i = 0; i < a.length; i++) {
			if (!kTraSoChinhPhuong(a[i])) {
				b[j++] = a[i];
			}
		}
		a = b;
		return a;
	}

}
