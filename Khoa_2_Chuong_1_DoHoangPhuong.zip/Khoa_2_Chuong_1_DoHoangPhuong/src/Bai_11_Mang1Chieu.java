//xóa các phần tử lớn nhất
import java.util.Scanner;

public class Bai_11_Mang1Chieu {

	public Bai_11_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		int max = timPhanTuLonNhat(a);
		System.out.println(max);
		a = xoaPhanTuLonNhat(a, max);
		System.out.println("Mảng sau khi xóa phần tử lớn nhất là");
		xuatMang(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 1");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 2);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static int timPhanTuLonNhat(int a[]) {
		int max = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
			}
		}
		return max;
	}

	public static int[] xoaPhanTuLonNhat(int a[], int max) {
		int count = 0;
		for (int item : a) {
			if (item == max) {
				count++;
			}
		}
		int b[] = new int[a.length - count];
		int j = 0;
		for (int i = 0; i < a.length; i++) {

			if (a[i] != max) {
				b[j++] = a[i];
			}
		}
		a = b;
		return a;
	}

}
