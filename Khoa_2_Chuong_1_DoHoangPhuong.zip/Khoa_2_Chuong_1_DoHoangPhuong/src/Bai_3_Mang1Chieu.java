//liệt kê số chẵn trong đoạn xy
import java.util.Scanner;

public class Bai_3_Mang1Chieu {

	static final int MIN = -100;
	static final int MAX = 100;

	public Bai_3_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = taoMang(n);
		xuatMang(a);
		int x = nhapX(scan);
		int y = nhapY(scan, x);
		System.out.println("Các phần tử trong mảng thuộc [x,y] là:");
		lietKe(a, x, y);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n chẵn và n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 2 || n % 2 != 0);
		return n;
	}

	public static int[] taoMang(int n) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = MIN + (int) (Math.random() * ((MAX - MIN) + 1));
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int item : a) {
			System.out.print(item + "\t");
		}
		System.out.println("\n");
	}

	public static int nhapX(Scanner scan) {
		int x;
		do {
			System.out.println("Mời nhập x trong đoạn [" + MIN + ';' + MAX + ']');
			x = Integer.parseInt(scan.nextLine());
		} while (x < MIN || x > MAX);
		return x;
	}

	public static int nhapY(Scanner scan, int x) {
		int y;
		do {
			System.out.println("Mời nhập y trong đoạn [" + MIN + ';' + MAX + ']');
			System.out.println("y > x");
			y = Integer.parseInt(scan.nextLine());
		} while (y < MIN || y > MAX || y <= x);
		return y;
	}

	public static void lietKe(int a[], int x, int y) {
		for (int i = 0; i < a.length; i++) {
			if (a[i] >= x && a[i] <= y && a[i] % 2 == 0) {
				System.out.print("a[" + i + "]:" + a[i] + "\t");
			}
		}
	}

}
