//trung bình cộng những phần tử lớn hơn x
import java.util.Scanner;

public class Bai_10_Mang1Chieu {

	static final int MIN = -1000;
	static final int MAX = 1000;

	public Bai_10_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = taoMang(n);
		xuatMang(a);
		System.out.println("Mời nhập vào số x");
		int x = Integer.parseInt(scan.nextLine());
		lietKe(a, x);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] taoMang(int n) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = MIN + (int) (Math.random() * ((MAX - MIN) + 1));
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static void lietKe(int a[], int x) {
		int sum = 0;
		int count = 0;
		float tbCong = 0;
		for (int i = 0; i < a.length; i++) {
			if (a[i] > x) {
				System.out.print("a[" + i + "]:" + a[i] + "\n");
				sum += a[i];
				count++;
			}
		}
		System.out.println("\n");
		if (count == 0) {
			System.out.println("Mảng không có phần tử lớn hơn x");
		} else {
			tbCong = (1.0f * sum) / count;
			System.out.println("Trung bình cộng những phần tử lớn hơn x là: " + tbCong);
		}
	}

}
