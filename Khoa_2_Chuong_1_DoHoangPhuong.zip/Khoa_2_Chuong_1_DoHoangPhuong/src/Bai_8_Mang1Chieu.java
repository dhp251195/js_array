
//Tổng các giá trị lớn hơn trị tuyệt đối giá trị đứng liền sau nó
import java.util.Scanner;

public class Bai_8_Mang1Chieu {

	static final int MIN = -1000;
	static final int MAX = 1000;

	public Bai_8_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = taoMang(n);
		xuatMang(a);
		ketQua(a);

	}

	public static int nhapN(Scanner scan) {
		int n;
		System.out.println("Nhập mảng n phần tử");
		do {
			System.out.println("Nhập n > 0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static int[] taoMang(int n) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = MIN + (int) (Math.random() * ((MAX - MIN) + 1));
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static void ketQua(int a[]) {
		int sum = 0;
		for (int i = 0; i < a.length - 1; i++) {
			if (Math.abs(a[i]) > Math.abs(a[i + 1])) {
				sum += a[i];
			}
		}
		System.out.println("Tổng các giá trị lớn hơn trị tuyệt đối giá trị đứng liền sau nó là: " + sum);
	}

}
