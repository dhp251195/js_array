//liệt kê cặp giá trị gần nhau nhất
import java.util.Scanner;

public class Bai_2_Mang1Chieu {

	public Bai_2_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		capGiaTriGanNhauNhat(a);
		int minusMin = capGiaTriGanNhauNhat(a);
		lietKe(a, minusMin);

	}

	public static int nhapN(Scanner scan) {
		int n = 0;
		System.out.println("Mời nhập mảng n phần tử");
		do {
			System.out.println("n>2");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 3);
		return n;
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static int capGiaTriGanNhauNhat(int a[]) {
		int minus = 0;
		int head = 0;
		int minusMin = Math.abs(a[0] - a[1]);
		do {
			for (int i = head; i < a.length - 1; i++) {
				minus = Math.abs(a[head] - a[i + 1]);
				if (minus < minusMin && minus != 0) {
					minusMin = minus;
				}
			}
			head++;
		} while (head < a.length);
		return minusMin;
	}

	public static void lietKe(int a[], int minusMin) {
		System.out.println("Những cặp giá trị gần nhau nhất là");
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				int minus = Math.abs(a[i] - a[j]);
				if (minus == minusMin && minus != 0) {
					System.out.println("a[" + i + "]" + a[i] + " && " + "a[" + j + "]" + a[j]);
				}

			}
		}
	}
}
