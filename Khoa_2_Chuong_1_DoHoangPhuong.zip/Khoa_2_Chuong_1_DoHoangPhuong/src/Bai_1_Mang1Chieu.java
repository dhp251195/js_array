
//liệt kê các giá trị dạng 3^k
import java.util.Scanner;

public class Bai_1_Mang1Chieu {

	public Bai_1_Mang1Chieu() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = nhapN(scan);
		int a[] = nhapMang(n, scan);
		xuatMang(a);
		lietKe(a);
	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]:");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;
	}

	public static int nhapN(Scanner scan) {
		int n = 0;
		System.out.println("Mời nhập mảng n phần tử");
		do {
			System.out.println("n>0");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 1);
		return n;
	}

	public static void xuatMang(int a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]:" + a[i] + "\t");
		}
		System.out.println("\n");
	}

	public static int kTraDieuKien(int x) {
		if (x == 1) {
			return 1;
		} else if (x > 1) {
			while (x > 1) {
				if (x % 3 != 0) {
					return 0;
				}
				x /= 3;
			}
			return 1;
		}return 0;
	}

	public static void lietKe(int a[]) {
		System.out.println("Những phần tử thỏa mãn điều kiện là");
		for (int i = 0; i < a.length; i++) {
			if (kTraDieuKien(a[i]) == 1) {
				System.out.print("a[" + i + "]:" + a[i] + "\t");
			}
		}
	}
}
